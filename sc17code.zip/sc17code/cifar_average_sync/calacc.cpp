#include<stdio.h>
#include<string>

using namespace std;

int main (int argc, char *argv[])
{
	if(argc!=2)
        {
                printf("Usage: ./execute num\n");
		return 0;
        }
	int n = atoi(argv[1]);
	FILE* file[512];
	for(int i=0;i<n;i++)
	{	
		string accname = "accuracy" + to_string(i) + ".txt";
		file[i] = fopen(accname.c_str(), "r");
		if(file[i]==NULL)
		{
			printf("File Not Exist!\n");
			return 0;
		}
	}
	float max, acc;
	while(fscanf(file[0], "%f", &acc)!=EOF)
	{
		max = acc;
		for(int i=1;i<n;i++)
		{
			fscanf(file[i], "%f", &acc);
			if(max<acc)	max = acc;
		}
		printf("%f ", max);
	}
	printf("\n");
	return 0;
}
