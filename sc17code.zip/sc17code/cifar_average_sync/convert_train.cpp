#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
using namespace std;

int main (int argc, char *argv[])
{
	if(argc!=2)
        {
                printf("Usage: ./execute num\n");
		return 0;
        }
	int n = atoi(argv[1]);
	for(int j=1;j<n;j++)
	{
  		string text;
  		string temp;
  		ifstream file;
  		file.open ("0cifar10_full_train_test.prototxt");
  		ofstream newfile;
		string id = to_string(j);
  		newfile.open (id + "cifar10_full_train_test.prototxt");
		int i = 0;
  		while (!file.eof())
  		{
    			getline (file, temp);
			if(i==10)	temp.replace(51, 1, id);
			if(i==14)	temp.replace(48, 1, id);
			if(i==28)	temp.replace(51, 1, id);
			if(i==31)	temp.replace(48, 1, id);
    			text.append (temp); // Added this line
    			text.append ("\n");
			i++;
  		}
  		newfile << text << "\n";
  		file.close();
		newfile.close();
	}

  	return 0;
}
