#define CPU_ONLY 1
#define BLAS mkl
#define USE_MKL2017_AS_DEFAULT_ENGINE 0
#define MKL2017_SUPPORTED 0
#define DISTR_WEIGHT_UPDATE
#include <caffe/caffe.hpp>
#include <stdlib.h>
#include <memory>
#include <vector>
#include <iostream>
#include <mpi.h>
#include <sstream>
#include <string>
//#include "caffe/layers/memory_data_layer.hpp"
using namespace std;
using namespace caffe;

void copy_params_from_net(shared_ptr<Net<float> > net, float* params)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        memcpy(params+offset, net_param->cpu_data(), sizeof(float)*net_param->count());
        offset += net_param->count();
    }
}

void copy_diffs_from_net(shared_ptr<Net<float> > net, float* diffs)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        memcpy(diffs+offset, net_param->cpu_diff(), sizeof(float)*net_param->count());
        offset += net_param->count();
    }
}

void copy_params_to_net(shared_ptr<Net<float> > net, float* params)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        net_param->set_cpu_data(params + offset);
        offset += net_param->count();
    }
}

void copy_diffs_to_net(shared_ptr<Net<float> > net, float* diffs)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        net_param->set_cpu_diff(diffs + offset);
        offset += net_param->count();
    }
}

void find_net_size(shared_ptr<Net<float> > net, int & param_size)
{
    	std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    	param_size = 0;
    	for (int i = 0; i < net_params.size(); ++i)
    	{
        	const Blob<float>* net_param = net_params[i].get();
        	param_size += net_param->count();
    	}
}

int main(int argc, char** argv)
{
	float rho = atof(argv[1]);
	MPI_Init(NULL, NULL);
	int world_size;
    	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	int world_rank;
    	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    	caffe::SolverParameter solver_param;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
    	int name_len;
    	MPI_Get_processor_name(processor_name, &name_len);
	string Result;
	ostringstream convert;
	convert << world_rank;
	Result = convert.str();
        string accuracyname = "accuracy" + Result + ".txt";
        string timename = "time" + Result + ".txt";
      	char rankid = '0' + world_rank;
      	//accuracyname[8] = rankid;
      	//timename[4] = rankid;
     	ofstream faccu;
      	faccu.open(accuracyname.c_str());
      	faccu.close();
     	ofstream ftime;
      	ftime.open(timename.c_str());
      	ftime.close();
    	printf("Hello world from processor %s, rank %d" " out of %d processors\n", processor_name, world_rank, world_size);
	string solvername = Result + "solver.prototxt";
	//solvername[0] = rankid;
    	caffe::ReadSolverParamsFromTextFileOrDie(solvername, &solver_param);
    	boost::shared_ptr<caffe::Solver<float> > solver(caffe::SolverRegistry<float>::CreateSolver(solver_param));
	shared_ptr<Net<float> > myNet;
	myNet = solver->net();
	int param_size;
        solver->mpi_rank = world_rank;
        solver->mpi_size = world_size;
	find_net_size(myNet, param_size);
	printf("****** rank %d: number of layers is %d, paramter size is %d ******\n", world_rank, (int)(myNet->params().size()), param_size);
	float * local_param = (float *)malloc(param_size*sizeof(float));
	float * local_diff = (float *)malloc(param_size*sizeof(float));
	float * global_diff = (float *)malloc(param_size*sizeof(float));
	copy_params_from_net(myNet, local_param);
	MPI_Bcast(local_param, param_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
	copy_params_to_net(myNet, local_param);
	double total_time = 0; 
	for(int i=0;i<2000;i++)
	{
		total_time -= MPI_Wtime();
		solver->Step(1);
		//copy_params_from_net(myNet, local_param);
		copy_diffs_from_net(myNet, local_diff);
		MPI_Reduce(local_diff, global_diff, param_size, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
		if(world_rank==0)
		{
			#pragma omp parallel for
			#pragma simd
			for(int j=0;j<param_size;j++)
			{
				local_param[j] -= (global_diff[j]); 
			}
		}
		MPI_Bcast(local_param, param_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
		copy_params_to_net(myNet, local_param);
		total_time += MPI_Wtime();
		if(i%50==0)
		{
			ftime.open(timename.c_str(), std::ofstream::out | std::ofstream::app);
      			ftime << total_time << " ";
      			ftime.close();
		}
	}
	MPI_Finalize();
	return 0;
}
