#define CPU_ONLY 1
#define BLAS mkl
#define USE_MKL2017_AS_DEFAULT_ENGINE 0
#define MKL2017_SUPPORTED 0
#define DISTR_WEIGHT_UPDATE
#include <caffe/caffe.hpp>
#include <stdlib.h>
#include <memory>
#include <vector>
#include <iostream>
#include <mpi.h>
#include <string>
#include <ctime>
//#include "caffe/layers/memory_data_layer.hpp"
using namespace std;
using namespace caffe;

void copy_params_from_net(shared_ptr<Net<float> > net, float* params)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        memcpy(params+offset, net_param->mutable_cpu_data(), sizeof(float)*net_param->count());
        //net_param->set_cpu_data(params + offset);
        offset += net_param->count();
    }
}

void copy_params_to_net(shared_ptr<Net<float> > net, float* params)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        net_param->set_cpu_data(params + offset);
        offset += net_param->count();
    }
}

void find_net_size(shared_ptr<Net<float> > net, int & param_size)
{
    	std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    	param_size = 0;
    	for (int i = 0; i < net_params.size(); ++i)
    	{
        	const Blob<float>* net_param = net_params[i].get();
        	param_size += net_param->count();
    	}
}

void copy_diffs_from_net(shared_ptr<Net<float> > net, float* diffs)
{
    std::vector<shared_ptr<Blob<float> > > net_params = net->params();
    int offset = 0;
    for (int i = 0; i < net_params.size(); ++i)
    {
        Blob<float>* net_param = net_params[i].get();
        memcpy(diffs+offset, net_param->cpu_diff(), sizeof(float)*net_param->count());
        offset += net_param->count();
    }
}

int main(int argc, char** argv)
{
	float rho = atof(argv[1]);
	MPI_Init(NULL, NULL);
	int world_size;
    	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	int world_rank;
    	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    	caffe::SolverParameter solver_param;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
    	int name_len;
    	MPI_Get_processor_name(processor_name, &name_len);
	string Result;
        ostringstream convert;
        convert << world_rank;
        Result = convert.str();
  	char buffer[80];
	if(world_rank==0)
	{
		time_t rawtime;
  		struct tm * timeinfo;
  		time (&rawtime);
  		timeinfo = localtime(&rawtime);
  		strftime(buffer,sizeof(buffer),"%d-%m-%Y_%I-%M-%S",timeinfo);
  	}
	MPI_Bcast(buffer, 80, MPI_CHAR, 0, MPI_COMM_WORLD);
	string time_str(buffer);
        string accuracyname = time_str + "accuracy" + Result + ".txt";
        string timename = time_str + "time" + Result + ".txt";
    	cout<<"Hello world from processor "<<processor_name<<", rank "<<world_rank<<" out of "<<world_size<<" processors\n";
	string solvername = Result + "solver.prototxt";
	char rankid = '0' + world_rank;
	ofstream faccu;
        faccu.open(accuracyname.c_str());
        faccu.close();
        ofstream ftime;
        ftime.open(timename.c_str());
        ftime.close();
    	caffe::ReadSolverParamsFromTextFileOrDie(solvername, &solver_param);
    	boost::shared_ptr<caffe::Solver<float> > solver(caffe::SolverRegistry<float>::CreateSolver(solver_param));
	shared_ptr<Net<float> > myNet;
	myNet = solver->net();
	solver->mpi_rank = world_rank;
        solver->mpi_size = world_size;
	int param_size;
	find_net_size(myNet, param_size);
	cout<< "****** rank "<<world_rank<<": number of layers is "<<myNet->params().size()<<", paramter size is "<<param_size<<"\n";
	float * local_param = (float *)malloc(param_size*sizeof(float));
	float * global_param = (float *)malloc(param_size*sizeof(float));
	float * local_diffs = (float *)malloc(param_size*sizeof(float));
	copy_params_from_net(myNet, local_param);
	MPI_Bcast(local_param, param_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
	copy_params_to_net(myNet, local_param);
	float * sum_param;
	if(world_rank==0)
	{	
		copy_params_from_net(myNet, global_param);
		sum_param = (float *)malloc(param_size*sizeof(float));
	}
	double total_time = 0;
	for(int i=0;i<1501;i++)
	{
		total_time -= MPI_Wtime();
		float alpha = rho * (solver->global_learning_rate);
		float beta = world_size * alpha;
		MPI_Bcast(global_param, param_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
		copy_params_from_net(myNet, local_param);
		MPI_Reduce(local_param, sum_param, param_size, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
		//if(i%100==0 && world_rank==0)	copy_params_to_net(myNet, global_param);
		solver->Step(1);
		copy_diffs_from_net(myNet, local_diffs);
		#pragma omp parallel for
		#pragma simd
		for(int j=0;j<param_size;j++)
		{
			local_param[j] = local_param[j] - local_diffs[j] - alpha*(local_param[j] - global_param[j]);
		}
		copy_params_to_net(myNet, local_param);
		if(world_rank==0)
		{
			#pragma omp parallel for
			#pragma simd
			for(int j=0;j<param_size;j++)
			{
				global_param[j] = (1 - beta)*global_param[j] + beta*(sum_param[j]/world_size);
			}
			copy_params_to_net(myNet, global_param);
		}
		total_time += MPI_Wtime();
		if(i%100==0)
                {
                        ftime.open(timename.c_str(), std::ofstream::out | std::ofstream::app);
                        ftime << total_time << " ";
                        ftime.close();
                        faccu.open(accuracyname.c_str(), std::ofstream::out | std::ofstream::app);
                        faccu << solver->my_accuracy << " ";
                        faccu.close();
                }
	}
	MPI_Finalize();
	return 0;
}
