rm mpiexecute
rm *.o

module swap craype-haswell craype-mic-knl
module load protobuf/2.6.1
module load boost/1.55.0
module load gflags/2.1.2
module load glog/0.3.4
export LD_LIBRARY_PATH=/usr/common/software/gflags/2.1.2/intel/lib:$LD_LIBRARY_PATH
module load snappy/1.1.3
module load leveldb/1.18
module load lmdb/0.9.18
module load opencv/3.1.0-nogui

export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/global/homes/y/yyang420/caffe_intel_test/build/lib
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/common/software/gflags/2.1.2/intel/lib
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/global/homes/y/yyang420/caffe_intel_test/external/mkl/mklml_lnx_2017.0.2.20170110/lib

CC -I/global/homes/y/yyang420/caffe_intel_test/include -I/usr/common/software/opencv/3.1.0-nogui/intel/include -I/usr/common/software/hdf5-serial/1.8.16/hsw/intel/include -I/usr/common/software/boost/1.55.0/hsw/intel/include -I/global/homes/y/yyang420/caffe_intel/external/mkl/mklml_lnx_2017.0.2.20170110/include -qopenmp -c mpi_caffe.cpp

CC -o mpiexecute mpi_caffe.o -dynamic -L/global/homes/y/yyang420/caffe_intel_test/build/lib -lcaffe -L/usr/common/software/boost/1.55.0/hsw/intel/lib -lboost_system -lboost_filesystem -lboost_regex -L/usr/common/software/protobuf/2.6.1/intel/lib -lprotobuf -L/usr/common/software/glog/0.3.4/intel/lib -lglog -L/usr/common/software/gflags/2.1.2/intel/lib -lgflags -L/global/homes/y/yyang420/caffe_intel_test/external/mkl/mklml_lnx_2017.0.2.20170110/lib -lmklml_intel -qopenmp
