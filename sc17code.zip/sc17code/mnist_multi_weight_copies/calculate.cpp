#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
	int p = stoi(argv[1]);
	FILE * fin = fopen("accuracy0", "");
	while()
	{}
	return 0;
}
